var issue = [
  { 'severity': 0, 'type': 10505, 'sid': '0', 'extra': '', 'fetched': true, 'code': 302, 'len': 1248, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': 'UTF-8', 'dir': 'i0' },
  { 'severity': 0, 'type': 10505, 'sid': '0', 'extra': 'identifier-captcha-input', 'fetched': true, 'code': 200, 'len': 79040, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'dir': 'i1' },
  { 'severity': 0, 'type': 10404, 'sid': '0', 'extra': 'Directory listing', 'fetched': true, 'code': 200, 'len': 1427, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'dir': 'i2' },
  { 'severity': 0, 'type': 10205, 'sid': '0', 'extra': '', 'fetched': true, 'code': 404, 'len': 1173, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'dir': 'i3' },
  { 'severity': 0, 'type': 10205, 'sid': '0', 'extra': '', 'fetched': true, 'code': 403, 'len': 1041, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'dir': 'i4' },
  { 'severity': 0, 'type': 10202, 'sid': '0', 'extra': 'Apache/2.4.23 (Win32) OpenSSL/1.0.2h PHP/5.6.28', 'fetched': true, 'code': 200, 'len': 1427, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i5' }
];
