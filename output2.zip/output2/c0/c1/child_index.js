var child = [
  { 'dupe': false, 'type': 32, 'name': 'hosts0.js', 'dir': 'c0', 'linked': 1, 'url': 'http://10.0.2.2/etc/hosts0.js', 'fetched': true, 'code': 404, 'len': 1173, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xffdfffff },
  { 'dupe': true, 'type': 32, 'name': 'passwd0.js', 'dir': 'c1', 'linked': 1, 'url': 'http://10.0.2.2/etc/passwd0.js', 'fetched': true, 'code': 404, 'len': 1173, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': true, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xffdfffff }
];
