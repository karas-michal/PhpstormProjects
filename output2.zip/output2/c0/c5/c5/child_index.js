var child = [
  { 'dupe': false, 'type': 64, 'name': '=1', 'dir': 'c0', 'linked': 5, 'url': 'http://10.0.2.2/krypto4/welcome.php?=1', 'fetched': true, 'code': 302, 'len': 1248, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 1, 0 ], 'sig': 0xe687d3a0 }
];
