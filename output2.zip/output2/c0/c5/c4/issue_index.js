var issue = [
  { 'severity': 3, 'type': 40402, 'sid': '22012', 'extra': 'PHP notice (HTML)', 'fetched': true, 'code': 302, 'len': 136, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i0' },
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Powered-By', 'fetched': true, 'code': 302, 'len': 136, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i1' }
];
