var child = [
  { 'dupe': false, 'type': 64, 'name': '=1', 'dir': 'c0', 'linked': 5, 'url': 'http://10.0.2.2/krypto4/login.php?=1', 'fetched': true, 'code': 200, 'len': 1178, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xffbfffff }
];
