var issue = [
  { 'severity': 3, 'type': 40402, 'sid': '22012', 'extra': 'PHP notice (HTML)', 'fetched': true, 'code': 302, 'len': 1405, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i0' },
  { 'severity': 0, 'type': 10601, 'sid': '0', 'extra': '', 'fetched': true, 'code': 302, 'len': 1405, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': 'UTF-8', 'dir': 'i1' },
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Powered-By', 'fetched': true, 'code': 302, 'len': 1405, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i2' }
];
